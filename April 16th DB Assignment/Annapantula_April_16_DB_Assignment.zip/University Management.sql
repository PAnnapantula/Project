use UniversitySoftware

--University Software--

CREATE TABLE Department(
	Department_ID int PRIMARY KEY,
	Department_Name varchar(50)
);

select * from Department;

CREATE TABLE Faculty(
	Faculty_ID int PRIMARY KEY,
	Faculty_Name varchar(100),
	Gender varchar(10),
	Designation varchar(50),
	Age int
);

select * from Faculty;

CREATE TABLE Course(
	Course_ID int PRIMARY KEY,
	Course_Name varchar(50),
	Code varchar(30),
	Department_ID int FOREIGN KEY REFERENCES Department(Department_ID),
	Faculty_ID int FOREIGN KEY REFERENCES Faculty(Faculty_ID)
);

select * from Course;

CREATE TABLE Research_Project(
	Project_ID int PRIMARY KEY,
	Project_Name varchar(50),
	Faculty_ID int FOREIGN KEY REFERENCES Faculty(Faculty_ID),
	Area varchar(50),
	Duration int,
	Completion_Date date
);

select * from Research_Project;

CREATE TABLE Student(
	Sudent_ID int PRIMARY KEY,
	First_Name varchar(50),
	Last_Name varchar(50),
	DOB date,
	Gender varchar(10),
	Phone int,
	Email varchar(50),
	Nationality varchar(30),
	Stud_Street varchar(50),
	Stud_City varchar(50),
	Stud_State varchar(50),
	Stud_Zipcode varchar(50),
	Department_ID int FOREIGN KEY REFERENCES Department(Department_ID),
	Project_ID int FOREIGN KEY REFERENCES Research_Project(Project_ID)
);

select * from Student;