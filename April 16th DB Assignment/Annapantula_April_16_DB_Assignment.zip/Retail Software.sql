use April16DBAssignment

--Retail Software [Ex. Amazon]--

CREATE TABLE Customer (
	Customer_ID int PRIMARY KEY,
	First_Name varchar(50),
	Last_Name varchar(50),
	Street varchar(50),
	City varchar(50),
	Zipcode varchar(50),
	Phone int,
	Email varchar(50)
);

select * from Customer;

CREATE TABLE Product (
	Product_ID int PRIMARY KEY,
	Product_Name varchar(50),
	Quantity_in_stock int,
	Unit_Price int,
	Product_Type varchar(50)
);

select * from Product;

CREATE TABLE Payment (
	Payment_ID int PRIMARY KEY,
	Credit_Card int,
	Name_on_Card varchar(30),
	Card_Expires_On varchar(30),
	Billing_Address varchar(80)
);

select * from Payment;

CREATE TABLE Orders (
	Order_Number int PRIMARY KEY,
	Customer_ID int FOREIGN KEY REFERENCES Customer(Customer_ID),
	Customer_Name varchar(50),
	To_Street varchar(50),
	To_City varchar(50),
	To_Zipcode varchar(50),
	Ship_Date date,
	Product_ID int FOREIGN KEY REFERENCES Product(Product_ID),
	Ordered_Qty int,
	Payment_ID int FOREIGN KEY REFERENCES Payment(Payment_ID),
	Total_Price int
);

select * from Orders;