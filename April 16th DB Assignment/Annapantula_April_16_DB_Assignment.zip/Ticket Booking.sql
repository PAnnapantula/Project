use TicketBooking

--Ticket Booking--

CREATE TABLE Flight(
	Flight_ID int PRIMARY KEY,
	Airline_ID int,
	Airline_Name varchar(50),
	Total_Seats int
);

select * from Flight;

CREATE TABLE Flight_Details(
	Flight_ID int FOREIGN KEY REFERENCES Flight(Flight_ID),
	From_Location varchar(50),
	To_Location varchar(50),
	Departure_Time DateTime PRIMARY KEY,
	Arrival_Time DateTime,
	Price int,
	Available_Seats int
);

select * from Flight_Details;

CREATE TABLE Credit_Card_Details(
	Profile_ID int PRIMARY KEY,
	Card_Number int,
	Expiration_Month int,
	Expiration_Year int
);

select * from Credit_Card_Details;

CREATE TABLE Passenger_Profile(
	Passenger_ID int PRIMARY KEY,
	Pass_Password varchar(100),
	Profile_ID int FOREIGN KEY REFERENCES Credit_Card_Details(Profile_ID),
	First_Name varchar(50),
	Last_Name varchar(50),
	Pass_Address varchar(200),
	Phone int,
	Email varchar(50)
);

select * from Passenger_Profile;

CREATE TABLE Ticket_Info(
	Ticket_ID int PRIMARY KEY,
	Passenger_ID int FOREIGN KEY REFERENCES Passenger_Profile(Passenger_ID),
	Flight_ID int FOREIGN KEY REFERENCES Flight(Flight_ID),
	Departure_Time DateTime FOREIGN KEY REFERENCES Flight_Details(Departure_Time),
	Passenger_Status varchar(30),
	Passenger_Name varchar(100),
	Seat_Assigned varchar(10)
);

select * from Ticket_Info;